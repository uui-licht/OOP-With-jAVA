class Hello5 {
    public static void main(String[] args) {
        System.out.print((10+5)*(4-6)/4);
    }
}
