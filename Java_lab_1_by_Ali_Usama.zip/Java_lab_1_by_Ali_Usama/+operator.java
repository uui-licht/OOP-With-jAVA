class Operator {
    public static void main(String[] args) {
        System.out.println("8 plus 5 is equal to " + (8 + 5));
    }
}
