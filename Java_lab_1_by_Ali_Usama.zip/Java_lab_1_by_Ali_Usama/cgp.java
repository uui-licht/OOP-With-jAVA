class cgp {
    public static void main(String[] args) {
        String name = "Usama";
        System.out.println("Name : " + name);
        int age = 19;
        System.out.println("Age : " + age);

        char grade = 'A';
        System.out.println("Grade : " + grade);
        double point = 7.8;
        System.out.println("Points : " + point);

        double cgp = 3.65;
        System.out.println("CGP : " + cgp);
        char gender = 'M';
        System.out.println("Gender : " + gender);
        boolean foreigner = false;
        System.out.println("Foreigner : " + foreigner);
    }
}
